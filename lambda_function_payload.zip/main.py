import boto3
import pymupdf


def lambda_handler(event, context):
    textract_client = boto3.client("textract")
    s3_client = boto3.client("s3")
    # Get the PDF object from S3
    bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = event["Records"][0]["s3"]["object"]["key"]
    obj = s3_client.get_object(
        Bucket=bucket,
        Key=key,
    )
    pdf_content = obj["Body"].read()

    # Open the PDF document using PyMuPDF
    pdf_doc = pymupdf.open(stream=pdf_content)

    # Convert each page of the PDF to a JPG image
    for i in range(len(pdf_doc)):
        page = pdf_doc[i]
        pixmap = page.get_pixmap(dpi=300)
        img = pixmap.tobytes()

        # Upload the JPG image to S3
        s3_client.put_object(
            Bucket=bucket,
            Key=f"processed/{event['Records'][0]['s3']['object']['key'].split('.')[0]}-page-{i + 1}.jpg",
            Body=img,
        )

    print(event)


if __name__ == "__main__":
    lambda_handler(
        {
            "Records": [
                {
                    "eventVersion": "2.1",
                    "eventSource": "aws:s3",
                    "awsRegion": "eu-west-3",
                    "eventTime": "2025-01-28T14:49:02.006Z",
                    "eventName": "ObjectCreated:Put",
                    "userIdentity": {"principalId": "AWS:AIDATMDN2HSWFD755GY2M"},
                    "requestParameters": {"sourceIPAddress": "77.132.39.200"},
                    "responseElements": {
                        "x-amz-request-id": "PXJTCZ9ZV3P9KE9T",
                        "x-amz-id-2": "wNWF9KIyGm8zii9flh88RniSwqcCJ20bbjfpkUowd3d9+WcYKYkhvXCxobb5lgYGmEQf4dno6ANsYOkS9Qkp/3noo0KR1CL9ekkJtkQ5kRM=",
                    },
                    "s3": {
                        "s3SchemaVersion": "1.0",
                        "configurationId": "tf-s3-lambda-20250128142629188800000001",
                        "bucket": {
                            "name": "test-bucket-rcanillas-28012025",
                            "ownerIdentity": {"principalId": "A3FVN5NA18LZ3D"},
                            "arn": "arn:aws:s3:::test-bucket-rcanillas-28012025",
                        },
                        "object": {
                            "key": "raw/1737997243451.pdf",
                            "size": 357927,
                            "eTag": "5294a0e02abed3df1294758f16a5fb5f",
                            "sequencer": "006798EE5DE7E79F7F",
                        },
                    },
                }
            ]
        },
        {},
    )
